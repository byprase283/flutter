import 'package:flutter/material.dart';
import 'package:android_alarm_manager_plus/android_alarm_manager_plus.dart';
import '../utils/background_service.dart';

class HomePage extends StatefulWidget {
  final String title;
  const HomePage({super.key, required this.title});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final BackgroundService _service = BackgroundService();
  String _logMessage = 'Belum ada aksi';

  void _updateLog(String message) {
    setState(() {
      _logMessage = message;
    });
  }

  @override
  void initState() {
    super.initState();
    port.listen((__) async {
      await _service.someTask();
      _updateLog('🔥 Alarm fired dan task dijalankan');
    });

    // Opsional: Cancel semua alarm saat awal buka
    AndroidAlarmManager.cancel(1);
    AndroidAlarmManager.cancel(2);
    AndroidAlarmManager.cancel(3);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.title)),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ElevatedButton(
                child: const Text('Alarm with Delayed (Once)'),
                onPressed: () async {
                  await AndroidAlarmManager.oneShot(
                    const Duration(seconds: 5),
                    1,
                    BackgroundService.callback,
                    exact: true,
                    wakeup: true,
                  );
                  _updateLog('✅ Alarm (Delayed Once) dijalankan');
                },
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                child: const Text('Alarm with Date and Time (Once)'),
                onPressed: () async {
                  await AndroidAlarmManager.oneShotAt(
                    DateTime.now().add(const Duration(seconds: 5)),
                    2,
                    BackgroundService.callback,
                    exact: true,
                    wakeup: true,
                  );
                  _updateLog('✅ Alarm (Once at DateTime) dijalankan');
                },
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                child: const Text('Alarm with Periodic'),
                onPressed: () async {
                  await AndroidAlarmManager.periodic(
                    const Duration(seconds: 10),
                    3,
                    BackgroundService.callback,
                    startAt: DateTime.now(),
                    exact: true,
                    wakeup: true,
                  );
                  _updateLog('✅ Alarm periodic dijalankan');
                },
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                child: const Text('Cancel Alarm by Id'),
                onPressed: () async {
                  await AndroidAlarmManager.cancel(3);
                  _updateLog('❌ Alarm dengan ID 3 dibatalkan');
                },
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                child: const Text('Cancel Semua Alarm (1, 2, 3)'),
                onPressed: () async {
                  await AndroidAlarmManager.cancel(1);
                  await AndroidAlarmManager.cancel(2);
                  await AndroidAlarmManager.cancel(3);
                  _updateLog('❌ Semua alarm dibatalkan');
                },
              ),
              const SizedBox(height: 40),
              Text(
                _logMessage,
                style: const TextStyle(fontSize: 16, color: Colors.blueGrey),
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
