import 'dart:isolate';
import 'dart:ui';

final ReceivePort port = ReceivePort();

@pragma('vm:entry-point') // Anotasi class (optional, untuk berjaga-jaga)
class BackgroundService {
  static BackgroundService? _instance;
  static const String _isolateName = 'isolate';
  static SendPort? _uiSendPort;

  BackgroundService._internal() {
    _instance = this;
  }

  factory BackgroundService() => _instance ?? BackgroundService._internal();

  void initializeIsolate() {
    print("Initializing isolate...");
    IsolateNameServer.registerPortWithName(port.sendPort, _isolateName);
  }

  @pragma('vm:entry-point') // ← INI YANG WAJIB untuk callback alarm
  static Future<void> callback() async {
    print('Alarm fired!');
    _uiSendPort ??= IsolateNameServer.lookupPortByName(_isolateName);
    _uiSendPort?.send(null);
  }

  Future<void> someTask() async {
    print('Updated data from the background isolate');
  }
}
