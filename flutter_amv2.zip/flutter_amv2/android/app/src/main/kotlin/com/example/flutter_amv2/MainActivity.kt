package com.example.flutter_amv2

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
