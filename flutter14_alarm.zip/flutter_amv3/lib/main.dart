import 'package:flutter/material.dart';
import 'package:android_alarm_manager_plus/android_alarm_manager_plus.dart';
import 'background_service.dart';
import 'home_page.dart';
import 'notification_helper.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await AndroidAlarmManager.initialize();
  await NotificationHelper.init();

  runApp(const MyApp());

  // Schedule alarm to run every 1 minute
  await AndroidAlarmManager.periodic(
    const Duration(minutes: 1),
    0, // alarm ID
    BackgroundService.callbackDispatcher,
    wakeup: true,
    exact: true,
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Alarm Manager Demo',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: const HomePage(),
    );
  }
}
