import 'package:flutter/material.dart';
import 'package:android_alarm_manager_plus/android_alarm_manager_plus.dart';
import 'background_service.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  final Color _buttonColor = const Color(0xFF6A1B9A); // Ungu

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF7EDF9),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            _buildButton(
              context,
              text: "Alarm with Delayed (Once)",
              onPressed: () {
                AndroidAlarmManager.oneShot(
                  const Duration(seconds: 5),
                  1,
                  BackgroundService.backgroundTask,
                  wakeup: true,
                );
              },
            ),
            _buildButton(
              context,
              text: "Alarm with Date and Time (Once)",
              onPressed: () {
                final now = DateTime.now();
                final scheduledTime = DateTime(
                  now.year,
                  now.month,
                  now.day,
                  now.hour,
                  now.minute + 1,
                );
                final delay = scheduledTime.difference(now);

                AndroidAlarmManager.oneShot(
                  delay,
                  2,
                  BackgroundService.backgroundTask,
                  wakeup: true,
                );
              },
            ),
            _buildButton(
              context,
              text: "Alarm with Periodic",
              onPressed: () {
                AndroidAlarmManager.periodic(
                  const Duration(minutes: 1),
                  3,
                  BackgroundService.backgroundTask,
                  wakeup: true,
                );
              },
            ),
            _buildButton(
              context,
              text: "Cancel Alarm by Id",
              onPressed: () {
                AndroidAlarmManager.cancel(1);
                AndroidAlarmManager.cancel(2);
                AndroidAlarmManager.cancel(3);
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildButton(
    BuildContext context, {
    required String text,
    required VoidCallback onPressed,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: ElevatedButton(
        onPressed: onPressed,
        style: ElevatedButton.styleFrom(
          elevation: 2,
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
          backgroundColor: Colors.white,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(30),
          ),
        ),
        child: Text(
          text,
          style: TextStyle(color: _buttonColor, fontWeight: FontWeight.w600),
        ),
      ),
    );
  }
}
