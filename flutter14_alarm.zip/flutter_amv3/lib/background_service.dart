import 'package:flutter/widgets.dart';
import 'notification_helper.dart';

class BackgroundService {
  static Future<void> backgroundTask() async {
    WidgetsFlutterBinding.ensureInitialized();
    await NotificationHelper.init();

    final now = DateTime.now();
    debugPrint("Alarm triggered at $now");

    await NotificationHelper.showNotification(
      "Alarm Triggered!",
      "Alarm fired at ${now.toLocal()}",
    );
  }

  // Tidak perlu pakai execute()
  static void callbackDispatcher() {
    // Kosong / opsional saja, tidak wajib isi apa-apa di versi ini
  }
}
