package com.example.android_alarm2025

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
